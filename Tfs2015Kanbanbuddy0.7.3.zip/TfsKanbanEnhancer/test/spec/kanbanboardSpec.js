/**
 * Created by siven on 11/10/15.
 */


describe("enhance board",function(){
    var settings = {"kanbanBoardColorMap":{"BL":"red","CR":"blue","AT":"yellow","Bug;BUG":"orange","TEST":"green","MA":"pink"},"kanbanBoardDescriptionMap":{"BL":"blocked","CR":"Change Request","AT":"","Bug;BUG":"Bug","TEST":"","MA":"Maintainance"},"taskBoardColorMap":{"DOC":"purple","DB":"lightgreen","UI":"gray"},"taskBoardDescriptionMap":{"DOC":"","DB":"","UI":""},"boardLinks":{"google":"http://google.com","Test":"test"}};
    beforeEach(function(){
        try{
            loadFixtures("spec/kanbanboard.html");
        }catch (e){}
        updateBoard(settings);
    });

    approveIt("should find tickets",function(approvals){
       approvals.verify($(".agile-board").html());
    });
});
